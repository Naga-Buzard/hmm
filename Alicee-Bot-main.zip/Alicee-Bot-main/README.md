## Alicee-Bot
BOT WHATSAPP YANG  BISA DIGUNAKAN DITERMUX
# KU HANYA GABOET MBAK GISEL...
# POWERED BY  : 19 DETIK



## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/habibhantam445/Alicee-Bot.git
> cd Alicee-Bot
> bash install.sh
> npm i
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             

ket : ✅ : aktif

# SPESIAL THANK'S
-HABIBHANTAM
-ALVIN
-WARGAINDONESIA
